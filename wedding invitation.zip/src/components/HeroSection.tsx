import { useState, useEffect } from "react";
import { motion } from "framer-motion";

const WEDDING_DATE = new Date("2026-04-19T10:15:00+05:30").getTime();

function getTimeLeft() {
  const diff = Math.max(0, WEDDING_DATE - Date.now());
  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

const HeroSection = () => {
  const [timeLeft, setTimeLeft] = useState(getTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => setTimeLeft(getTimeLeft()), 1000);
    return () => clearInterval(timer);
  }, []);

  const units = [
    { label: "DAYS", value: timeLeft.days },
    { label: "HOURS", value: timeLeft.hours },
    { label: "MINUTES", value: timeLeft.minutes },
    { label: "SECONDS", value: timeLeft.seconds },
  ];

  return (
    <section className="min-h-screen flex flex-col items-center justify-center py-20 px-4 relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, hsl(var(--gold) / 0.15) 0%, transparent 50%),
                            radial-gradient(circle at 80% 50%, hsl(var(--gold) / 0.15) 0%, transparent 50%)`
        }} />
      </div>

      {/* Ganesh */}
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 0.3 }}
        className="font-hindi text-gold text-lg sm:text-xl mb-8 tracking-wide"
      >
        || श्री गणेशाय नमः ||
      </motion.p>

      {/* Decorative divider */}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 1, delay: 0.6 }}
        className="w-32 h-px bg-gradient-to-r from-transparent via-gold to-transparent mb-10"
      />

      {/* Couple names */}
      <motion.h1
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.2, delay: 0.9 }}
        className="gold-shine text-6xl sm:text-8xl md:text-9xl font-royal font-bold tracking-wide text-center leading-tight"
      >
        Lokesh
      </motion.h1>

      <motion.span
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 1.4 }}
        className="text-4xl sm:text-5xl my-2 block"
      >
        ❤️
      </motion.span>

      <motion.h1
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.2, delay: 1.6 }}
        className="gold-shine text-6xl sm:text-8xl md:text-9xl font-royal font-bold tracking-wide text-center leading-tight"
      >
        Komal
      </motion.h1>

      {/* Divider */}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 1, delay: 2 }}
        className="w-48 h-px bg-gradient-to-r from-transparent via-gold to-transparent mt-10"
      />

      {/* Invitation text */}
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 2.3 }}
        className="font-hindi text-xl sm:text-2xl text-maroon mt-8 text-center"
      >
        आप सपरिवार आमंत्रित हैं
      </motion.p>

      {/* Countdown heading */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 2.8 }}
        className="font-hindi text-gold-light text-base sm:text-lg mt-12 mb-6 tracking-wide"
      >
        शुभ विवाह में शेष समय
      </motion.p>

      {/* Countdown Timer */}
      <div className="flex justify-center gap-3 sm:gap-5">
        {units.map((unit, i) => (
          <motion.div
            key={unit.label}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 3 + i * 0.12 }}
            className="flex flex-col items-center"
          >
            <div
              className="w-[4.2rem] h-[4.2rem] sm:w-[5.5rem] sm:h-[5.5rem] rounded-xl border border-gold/40 flex items-center justify-center relative overflow-hidden"
              style={{
                background: "linear-gradient(145deg, hsl(var(--maroon-deep) / 0.85), hsl(var(--maroon-deep) / 0.95))",
                boxShadow: "0 4px 24px hsl(var(--gold) / 0.1), inset 0 1px 0 hsl(var(--gold) / 0.08)",
              }}
            >
              {/* Subtle inner glow */}
              <div
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{
                  background: "radial-gradient(circle at 50% 30%, hsl(var(--gold) / 0.25), transparent 70%)",
                }}
              />
              <span
                className="relative text-2xl sm:text-4xl font-royal font-bold"
                style={{
                  color: "hsl(var(--gold-light))",
                  textShadow: "0 0 12px hsl(var(--gold) / 0.35)",
                }}
              >
                {String(unit.value).padStart(2, "0")}
              </span>
            </div>
            <span
              className="text-xs sm:text-sm mt-3 font-royal tracking-[0.25em] uppercase"
              style={{
                color: "hsl(var(--gold-light) / 0.75)",
                textShadow: "0 0 8px hsl(var(--gold) / 0.2)",
              }}
            >
              {unit.label}
            </span>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default HeroSection;
