import { motion } from "framer-motion";
import couple1 from "@/assets/couple-1.png";
import couple2 from "@/assets/couple-2.png";

const CoupleShowcase = () => {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-ivory-warm via-ivory to-ivory-warm overflow-hidden">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-center font-royal text-3xl sm:text-4xl gold-shine mb-4"
      >
        The Royal Couple
      </motion.h2>
      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.2 }}
        className="text-center font-hindi text-muted-foreground mb-12"
      >
        दो दिलों का मिलन
      </motion.p>

      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative group"
        >
          <div className="rounded-2xl overflow-hidden gold-border">
            <img
              src={couple1}
              alt="Lokesh & Komal"
              className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105"
              loading="lazy"
              width={768}
              height={1024}
            />
          </div>
          <div className="absolute -bottom-3 -right-3 w-20 h-20 border-2 border-gold/30 rounded-full" />
          <div className="absolute -top-3 -left-3 w-16 h-16 border-2 border-gold/20 rounded-full" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative group"
        >
          <div className="rounded-2xl overflow-hidden gold-border">
            <img
              src={couple2}
              alt="Lokesh & Komal together"
              className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105"
              loading="lazy"
              width={768}
              height={1024}
            />
          </div>
          <div className="absolute -bottom-3 -left-3 w-20 h-20 border-2 border-gold/30 rounded-full" />
          <div className="absolute -top-3 -right-3 w-16 h-16 border-2 border-gold/20 rounded-full" />
        </motion.div>
      </div>
    </section>
  );
};

export default CoupleShowcase;
