import { motion } from "framer-motion";
import { Crown } from "lucide-react";

const families = [
  {
    side: "Groom's Family",
    sideHindi: "वर पक्ष",
    father: "Mr. Rajendra Prasad",
    mother: "Mrs. Raajbai Devi",
  },
  {
    side: "Bride's Family",
    sideHindi: "वधू पक्ष",
    father: "Mr. Kailash Chand Bhimwal",
    mother: "Mrs. Manni Devi",
  },
];

const FamilyBlessings = () => {
  return (
    <section className="py-20 px-4 bg-maroon-deep relative overflow-hidden">
      {/* Subtle background pattern */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `radial-gradient(circle at 30% 40%, hsl(var(--gold) / 0.3) 0%, transparent 50%),
                          radial-gradient(circle at 70% 60%, hsl(var(--gold) / 0.3) 0%, transparent 50%)`
      }} />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-4"
      >
        <Crown className="w-8 h-8 text-gold mx-auto mb-4" />
        <h2 className="font-royal text-3xl sm:text-4xl text-gold-light tracking-wide">
          With Blessings Of
        </h2>
        <p className="font-hindi text-gold/70 mt-2 text-lg">
          शुभ आशीर्वाद
        </p>
      </motion.div>

      <div className="flex justify-center py-6">
        <div className="w-48 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
      </div>

      <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
        {families.map((family, i) => (
          <motion.div
            key={family.side}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.2, duration: 0.6 }}
            className="relative rounded-xl p-8 text-center"
            style={{
              background: "linear-gradient(145deg, hsl(0 60% 25% / 0.6), hsl(0 70% 18% / 0.8))",
              border: "1px solid hsl(var(--gold) / 0.3)",
            }}
          >
            <h3 className="font-royal text-xl text-gold-light tracking-wider mb-1">
              {family.side}
            </h3>
            <p className="font-hindi text-gold/60 text-sm mb-6">{family.sideHindi}</p>

            <div className="space-y-3">
              <p className="font-royal text-lg text-ivory tracking-wide">{family.father}</p>
              <div className="w-12 h-px bg-gold/30 mx-auto" />
              <p className="font-royal text-lg text-ivory tracking-wide">{family.mother}</p>
            </div>

            {/* Corner decorations */}
            <div className="absolute top-2 left-2 w-6 h-6 border-t border-l border-gold/30" />
            <div className="absolute top-2 right-2 w-6 h-6 border-t border-r border-gold/30" />
            <div className="absolute bottom-2 left-2 w-6 h-6 border-b border-l border-gold/30" />
            <div className="absolute bottom-2 right-2 w-6 h-6 border-b border-r border-gold/30" />
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default FamilyBlessings;
