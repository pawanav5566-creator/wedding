import { motion } from "framer-motion";
import { MapPin, Navigation } from "lucide-react";

const VenueSection = () => {
  const mapsUrl = "https://www.google.com/maps/search/Rampura,+Tehsil+Reni,+Alwar,+Rajasthan";

  return (
    <section className="py-16 px-4 max-w-2xl mx-auto">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-center font-royal text-3xl sm:text-4xl gold-shine mb-10"
      >
        Wedding Venue
      </motion.h2>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="rounded-xl overflow-hidden gold-border"
      >
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28400!2d76.5!3d27.7!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDQyJzAwLjAiTiA3NsKwMzAnMDAuMCJF!5e0!3m2!1sen!2sin!4v1"
          width="100%"
          height="250"
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Wedding Venue"
        />

        <div className="bg-ivory p-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-3">
            <MapPin className="w-5 h-5 text-maroon" />
            <p className="font-royal text-lg text-maroon font-semibold">
              Rampura, Tehsil Reni, Alwar
            </p>
          </div>
          <p className="text-sm text-muted-foreground mb-4 font-hindi">राजस्थान</p>
          <a
            href={mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-maroon text-primary-foreground px-6 py-3 rounded-lg font-royal tracking-wider hover:bg-maroon-deep transition-colors"
          >
            <Navigation className="w-4 h-4" />
            View Location
          </a>
        </div>
      </motion.div>
    </section>
  );
};

export default VenueSection;
