import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Volume2, VolumeX, Share2, CalendarHeart } from "lucide-react";

const FloatingActions = () => {
  const [musicPlaying, setMusicPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Use a royalty-free shehnai-style URL or silent fallback
    audioRef.current = new Audio(
      "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
    );
    audioRef.current.loop = true;
    audioRef.current.volume = 0.3;

    // Attempt autoplay
    audioRef.current.play().then(() => setMusicPlaying(true)).catch(() => {});

    return () => {
      audioRef.current?.pause();
    };
  }, []);

  const toggleMusic = () => {
    if (!audioRef.current) return;
    if (musicPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setMusicPlaying(!musicPlaying);
  };

  const shareOnWhatsApp = () => {
    const message = encodeURIComponent(
      "🎊 You're invited to Lokesh & Komal's Wedding! 🎊\n\n📅 19 April 2026\n📍 Rampura, Tehsil Reni, Alwar, Rajasthan\n\nOpen the invitation: " +
        window.location.href
    );
    window.open(`https://wa.me/?text=${message}`, "_blank");
  };

  const saveTheDate = () => {
    const event = [
      "BEGIN:VCALENDAR",
      "BEGIN:VEVENT",
      "DTSTART:20260419T041500Z",
      "DTEND:20260420T000000Z",
      "SUMMARY:Lokesh & Komal's Wedding",
      "LOCATION:Rampura, Tehsil Reni, Alwar, Rajasthan",
      "END:VEVENT",
      "END:VCALENDAR",
    ].join("\n");

    const blob = new Blob([event], { type: "text/calendar" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "wedding-lokesh-komal.ics";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed bottom-6 right-4 z-40 flex flex-col gap-3">
      {/* Music toggle */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={toggleMusic}
        className="w-12 h-12 rounded-full bg-maroon gold-border flex items-center justify-center shadow-lg"
        aria-label={musicPlaying ? "Mute music" : "Play music"}
      >
        {musicPlaying ? (
          <Volume2 className="w-5 h-5 text-gold-light" />
        ) : (
          <VolumeX className="w-5 h-5 text-gold-light" />
        )}
      </motion.button>

      {/* WhatsApp share */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={shareOnWhatsApp}
        className="w-12 h-12 rounded-full bg-maroon gold-border flex items-center justify-center shadow-lg"
        aria-label="Share on WhatsApp"
      >
        <Share2 className="w-5 h-5 text-gold-light" />
      </motion.button>

      {/* Save the date */}
      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={saveTheDate}
        className="w-12 h-12 rounded-full bg-maroon gold-border flex items-center justify-center shadow-lg"
        aria-label="Save the Date"
      >
        <CalendarHeart className="w-5 h-5 text-gold-light" />
      </motion.button>
    </div>
  );
};

export default FloatingActions;
