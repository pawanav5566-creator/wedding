import { motion } from "framer-motion";
import { Heart } from "lucide-react";

const SpecialNote = () => {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-ivory-warm to-ivory relative overflow-hidden">
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: `radial-gradient(circle at 50% 50%, hsl(var(--gold) / 0.3) 0%, transparent 60%)`
      }} />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="max-w-lg mx-auto text-center relative z-10"
      >
        <motion.div
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <Heart className="w-10 h-10 text-maroon mx-auto mb-6" fill="hsl(var(--maroon))" />
        </motion.div>

        <h2 className="font-royal text-2xl sm:text-3xl text-maroon mb-4 tracking-wide">
          A Special Note
        </h2>

        <p className="font-royal text-lg text-maroon-deep italic leading-relaxed mb-4">
          "Your presence will make our day truly special.
          <br />
          We look forward to celebrating this beautiful moment with you."
        </p>

        <div className="w-24 h-px bg-gradient-to-r from-transparent via-gold to-transparent mx-auto my-6" />

        <p className="font-hindi text-maroon text-lg">
          आपकी उपस्थिति ही हमारा सबसे बड़ा उपहार है
        </p>
      </motion.div>
    </section>
  );
};

export default SpecialNote;
