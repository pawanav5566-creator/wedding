import { motion } from "framer-motion";
import { Calendar, Sun, Sparkles, Heart, Music, Users, UtensilsCrossed, Moon } from "lucide-react";

const events = [
  {
    date: "15 April 2026",
    items: [{ name: "Lagan", time: "08:15 AM", icon: Calendar }],
  },
  {
    date: "17 April 2026",
    items: [{ name: "Tel", time: "Shubh Muhurat", icon: Sun }],
  },
  {
    date: "18 April 2026",
    items: [
      { name: "Haldi", time: "10:15 AM", icon: Sparkles },
      { name: "Mehendi", time: "12:15 PM", icon: Heart },
      { name: "Sangeet", time: "05:15 PM", icon: Music },
    ],
  },
  {
    date: "19 April 2026",
    items: [
      { name: "Barat", time: "10:15 AM", icon: Users },
      { name: "Preetibhoj", time: "12:15 PM onwards", icon: UtensilsCrossed },
      { name: "Wedding Rituals", time: "Night Muhurat", icon: Moon },
    ],
  },
];

const WeddingTimeline = () => {
  return (
    <section className="py-16 px-4 max-w-2xl mx-auto">
      <motion.h2
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="text-center font-royal text-3xl sm:text-4xl gold-shine mb-12"
      >
        Wedding Events
      </motion.h2>

      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-6 sm:left-8 top-0 bottom-0 w-px bg-gradient-to-b from-gold via-gold/50 to-gold" />

        {events.map((day, dayIndex) => (
          <motion.div
            key={day.date}
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: dayIndex * 0.15, duration: 0.6 }}
            className="mb-10"
          >
            {/* Date badge */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-maroon gold-border flex items-center justify-center z-10 shrink-0">
                <Calendar className="w-5 h-5 sm:w-6 sm:h-6 text-gold-light" />
              </div>
              <h3 className="font-royal text-xl sm:text-2xl text-maroon font-semibold">
                {day.date}
              </h3>
            </div>

            {/* Event cards */}
            <div className="ml-16 sm:ml-20 space-y-3">
              {day.items.map((event, eventIndex) => (
                <motion.div
                  key={event.name}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: dayIndex * 0.15 + eventIndex * 0.1 + 0.2 }}
                  className="bg-ivory rounded-lg p-4 border border-gold/20 hover:border-gold/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <event.icon className="w-5 h-5 text-gold shrink-0" />
                    <div>
                      <h4 className="font-royal text-lg font-semibold text-maroon">
                        {event.name}
                      </h4>
                      <p className="text-sm text-muted-foreground font-hindi">
                        {event.time}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default WeddingTimeline;
