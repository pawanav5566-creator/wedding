import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import palaceBg from "@/assets/palace-bg.jpg";
import waxSeal from "@/assets/wax-seal.png";

interface EnvelopeOpeningProps {
  onOpen: () => void;
}

const EnvelopeOpening = ({ onOpen }: EnvelopeOpeningProps) => {
  const [isOpening, setIsOpening] = useState(false);

  const handleClick = () => {
    setIsOpening(true);
    setTimeout(onOpen, 1800);
  };

  return (
    <AnimatePresence>
      {!isOpening ? (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center cursor-pointer"
          onClick={handleClick}
          exit={{ opacity: 0, scale: 1.1 }}
          transition={{ duration: 0.6 }}
        >
          {/* Background */}
          <div className="absolute inset-0">
            <img
              src={palaceBg}
              alt=""
              className="w-full h-full object-cover"
              width={1920}
              height={1080}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/50" />
          </div>

          {/* Envelope */}
          <motion.div
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{
              scale: 1,
              opacity: 1,
              y: [0, -10, 0],
            }}
            transition={{
              scale: { duration: 0.8, ease: "easeOut" },
              opacity: { duration: 0.8 },
              y: { duration: 3, repeat: Infinity, ease: "easeInOut" },
            }}
            className="relative z-10"
          >
            {/* Envelope body */}
            <div
              className="relative w-[320px] h-[220px] sm:w-[400px] sm:h-[280px] rounded-lg gold-border"
              style={{
                background: "linear-gradient(145deg, hsl(0 60% 25%), hsl(0 70% 18%))",
                animation: "envelope-glow 2s ease-in-out infinite",
              }}
            >
              {/* Flap (triangle) */}
              <div
                className="absolute top-0 left-0 right-0 h-1/2"
                style={{
                  background: "linear-gradient(180deg, hsl(0 70% 20%), hsl(0 60% 25%))",
                  clipPath: "polygon(0 0, 100% 0, 50% 100%)",
                  borderBottom: "2px solid hsl(40, 70%, 50%)",
                }}
              />

              {/* Gold inner lines */}
              <div className="absolute bottom-0 left-0 right-0 h-1/2">
                <svg className="w-full h-full" viewBox="0 0 400 140" preserveAspectRatio="none">
                  <line x1="0" y1="140" x2="200" y2="20" stroke="hsl(40, 70%, 50%)" strokeWidth="1" opacity="0.4" />
                  <line x1="400" y1="140" x2="200" y2="20" stroke="hsl(40, 70%, 50%)" strokeWidth="1" opacity="0.4" />
                </svg>
              </div>

              {/* Wax seal */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/4 z-10">
                <img
                  src={waxSeal}
                  alt="Royal Seal"
                  className="w-16 h-16 sm:w-20 sm:h-20 drop-shadow-lg"
                  width={512}
                  height={512}
                />
              </div>
            </div>

            {/* Tap hint */}
            <motion.p
              className="text-center mt-6 text-gold-light font-royal text-lg tracking-widest"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Tap to Open
            </motion.p>
          </motion.div>
        </motion.div>
      ) : (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center"
          initial={{ opacity: 1 }}
          animate={{ opacity: 0, scale: 1.3 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
        >
          <div className="absolute inset-0">
            <img src={palaceBg} alt="" className="w-full h-full object-cover" width={1920} height={1080} />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/50" />
          </div>

          {/* Golden light burst */}
          <motion.div
            className="relative z-10 rounded-full"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 8, opacity: [0, 1, 0] }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            style={{
              width: 100,
              height: 100,
              background: "radial-gradient(circle, hsl(40 80% 65% / 0.8), hsl(40 70% 50% / 0.3), transparent)",
            }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default EnvelopeOpening;
