import { motion } from "framer-motion";
import haldiImg from "@/assets/haldi-1.jpg";
import mehendiImg from "@/assets/mehendi-1.jpg";
import sangeetImg from "@/assets/sangeet-1.jpg";
import baratImg from "@/assets/barat-1.jpg";
import weddingImg from "@/assets/wedding-1.jpg";

interface EventSectionProps {
  title: string;
  titleHindi: string;
  description: string;
  image: string;
  bgClass: string;
  textClass: string;
  reverse?: boolean;
}

const EventSection = ({ title, titleHindi, description, image, bgClass, textClass, reverse }: EventSectionProps) => (
  <div className={`py-16 px-4 ${bgClass}`}>
    <div className={`max-w-4xl mx-auto flex flex-col ${reverse ? "md:flex-row-reverse" : "md:flex-row"} gap-8 items-center`}>
      <motion.div
        initial={{ opacity: 0, x: reverse ? 40 : -40 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
        className="flex-1 text-center md:text-left"
      >
        <h3 className={`font-royal text-3xl sm:text-4xl font-bold mb-2 ${textClass}`}>
          {title}
        </h3>
        <p className="font-hindi text-lg opacity-70 mb-4">{titleHindi}</p>
        <p className="font-royal text-base opacity-80 leading-relaxed tracking-wide">
          {description}
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7, delay: 0.15 }}
        className="flex-1 max-w-sm"
      >
        <div className="rounded-2xl overflow-hidden shadow-xl border border-gold/20">
          <img
            src={image}
            alt={title}
            className="w-full h-64 sm:h-80 object-cover"
            loading="lazy"
            width={640}
            height={640}
          />
        </div>
      </motion.div>
    </div>
  </div>
);

const events = [
  {
    title: "Haldi",
    titleHindi: "हल्दी",
    description: "A beautiful ceremony where turmeric paste is applied to the couple, symbolizing purification and blessings for the wedding day.",
    image: haldiImg,
    bgClass: "bg-gradient-to-br from-yellow-50 via-amber-50 to-yellow-100",
    textClass: "text-amber-800",
  },
  {
    title: "Mehendi",
    titleHindi: "मेहंदी",
    description: "The bride's hands and feet are adorned with intricate henna designs, each pattern telling a story of love and togetherness.",
    image: mehendiImg,
    bgClass: "bg-gradient-to-br from-emerald-50 via-green-50 to-emerald-100",
    textClass: "text-emerald-800",
    reverse: true,
  },
  {
    title: "Sangeet",
    titleHindi: "संगीत",
    description: "A night of music, dance, and celebrations where families come together to celebrate the joy of the upcoming union.",
    image: sangeetImg,
    bgClass: "bg-gradient-to-br from-purple-900 via-indigo-900 to-purple-950 text-ivory",
    textClass: "text-gold-light",
  },
  {
    title: "Barat",
    titleHindi: "बारात",
    description: "The grand procession where the groom arrives on a decorated horse, accompanied by music, dancing, and celebrations.",
    image: baratImg,
    bgClass: "bg-gradient-to-br from-orange-50 via-red-50 to-orange-100",
    textClass: "text-red-800",
    reverse: true,
  },
  {
    title: "Wedding Ceremony",
    titleHindi: "विवाह संस्कार",
    description: "The sacred rituals around the holy fire — varmala, pheras, and sindoor — binding two souls together for eternity.",
    image: weddingImg,
    bgClass: "bg-gradient-to-br from-red-900 via-maroon to-red-950 text-ivory",
    textClass: "text-gold-light",
  },
];

const EventGallery = () => {
  return (
    <section>
      <div className="py-12 px-4 bg-ivory-warm">
        <motion.h2
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center font-royal text-3xl sm:text-4xl gold-shine mb-2"
        >
          Wedding Celebrations
        </motion.h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-center font-hindi text-muted-foreground"
        >
          शादी के रंग
        </motion.p>
      </div>

      {events.map((event) => (
        <EventSection key={event.title} {...event} />
      ))}
    </section>
  );
};

export default EventGallery;
