import { motion } from "framer-motion";
import { BookOpen } from "lucide-react";

const InvitationStory = () => {
  return (
    <section className="py-20 px-4 relative overflow-hidden">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative rounded-xl p-8 sm:p-12 text-center"
          style={{
            background: "linear-gradient(145deg, hsl(35 40% 92%), hsl(30 30% 88%))",
            border: "2px solid hsl(var(--gold) / 0.3)",
            boxShadow: "0 10px 40px hsl(var(--gold) / 0.1), inset 0 0 60px hsl(var(--gold) / 0.05)",
          }}
        >
          <BookOpen className="w-8 h-8 text-gold mx-auto mb-6" />

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="font-hindi text-maroon text-lg sm:text-xl leading-relaxed mb-6"
          >
            हमारे जीवन के इस शुभ अवसर पर,
            <br />
            हम आपको सहर्ष आमंत्रित करते हैं।
            <br />
            आपकी उपस्थिति और आशीर्वाद से
            <br />
            यह अवसर और भी शुभ हो जाएगा।
          </motion.p>

          <div className="w-24 h-px bg-gradient-to-r from-transparent via-gold to-transparent mx-auto mb-6" />

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="font-royal text-maroon-deep text-base sm:text-lg italic tracking-wide"
          >
            On this auspicious occasion of our lives,
            <br />
            we cordially invite you to bless the union of
            <br />
            <span className="font-semibold text-maroon">Lokesh & Komal</span>
          </motion.p>

          {/* Parchment corner decorations */}
          <div className="absolute top-3 left-3 w-8 h-8 border-t-2 border-l-2 border-gold/40 rounded-tl-sm" />
          <div className="absolute top-3 right-3 w-8 h-8 border-t-2 border-r-2 border-gold/40 rounded-tr-sm" />
          <div className="absolute bottom-3 left-3 w-8 h-8 border-b-2 border-l-2 border-gold/40 rounded-bl-sm" />
          <div className="absolute bottom-3 right-3 w-8 h-8 border-b-2 border-r-2 border-gold/40 rounded-br-sm" />
        </motion.div>
      </div>
    </section>
  );
};

export default InvitationStory;
