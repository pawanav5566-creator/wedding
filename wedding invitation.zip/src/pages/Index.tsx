import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import EnvelopeOpening from "@/components/EnvelopeOpening";
import HeroSection from "@/components/HeroSection";
import CoupleShowcase from "@/components/CoupleShowcase";
import FamilyBlessings from "@/components/FamilyBlessings";
import InvitationStory from "@/components/InvitationStory";

import WeddingTimeline from "@/components/WeddingTimeline";
import EventGallery from "@/components/EventGallery";
import VenueSection from "@/components/VenueSection";
import SpecialNote from "@/components/SpecialNote";
import FloatingActions from "@/components/FloatingActions";

const Divider = () => (
  <div className="flex justify-center py-4">
    <div className="w-64 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
  </div>
);

const Index = () => {
  const [envelopeOpened, setEnvelopeOpened] = useState(false);

  return (
    <>
      <AnimatePresence>
        {!envelopeOpened && (
          <EnvelopeOpening onOpen={() => setEnvelopeOpened(true)} />
        )}
      </AnimatePresence>

      {envelopeOpened && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="min-h-screen bg-ivory-warm"
        >
          <FloatingActions />

          {/* Section 1: Grand Intro */}
          <HeroSection />

          <Divider />

          {/* Section 2: Couple Showcase */}
          <CoupleShowcase />

          <Divider />

          {/* Section 3: Family Blessings */}
          <FamilyBlessings />

          {/* Section 4: Invitation Story */}
          <InvitationStory />

          <Divider />

          {/* Section 5: Wedding Timeline */}
          <WeddingTimeline />

          {/* Section 6: Event Gallery */}
          <EventGallery />

          <Divider />

          {/* Section 7: Venue */}
          <VenueSection />

          <Divider />

          {/* Section 10: Special Note */}
          <SpecialNote />

          {/* Section 12: Footer */}
          <footer className="py-16 text-center bg-maroon-deep relative overflow-hidden">
            <div className="absolute inset-0 opacity-10" style={{
              backgroundImage: `radial-gradient(circle at 50% 50%, hsl(var(--gold) / 0.4) 0%, transparent 60%)`
            }} />
            <div className="relative z-10">
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="font-hindi text-gold/80 text-lg mb-3"
              >
                आपकी उपस्थिति हमारे लिए अमूल्य है
              </motion.p>
              <p className="text-gold-light/60 font-royal tracking-widest text-sm mb-6">
                Made with ❤️ for our wedding
              </p>
              <p className="text-gold/40 font-royal tracking-wider text-sm">
                With Love — Lokesh & Komal
              </p>
            </div>
          </footer>
        </motion.div>
      )}
    </>
  );
};

export default Index;
